
from lumi_core import LumiCore

def main():
    lumi = LumiCore()
    print("Lumi CLI ready. Type your message below.")
    while True:
        try:
            msg = input("You: ")
            if msg.lower() in ['exit', 'quit']:
                print("Exiting Lumi. Bye!")
                break
            lumi.receive(msg)
        except KeyboardInterrupt:
            print("\nInterrupted.")
            break

if __name__ == "__main__":
    main()
